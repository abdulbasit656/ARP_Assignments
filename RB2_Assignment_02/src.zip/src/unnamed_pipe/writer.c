// Unnamed Pipe Writer PROCESS 



// headers files
#include <stdio.h> //header file for input/output. 
#include <string.h> //header file for handle strings
#include <unistd.h> //header file for POSIX operating system API
#include <stdlib.h> //header file for general purpose standard library 
#include <sys/types.h> //header file for system source code data types
#include <sys/wait.h> // header file for symbolic constants 
#include <fcntl.h> //header file for file control
#include <time.h> //header file for time related functions
#include <errno.h> //header file for macros for "error number".

#define SIZE 1000000
// variable declaration

char buf[20], buf1[20], buf2[20], buf3[20];
int C1 = 0;
int C2 = 0;
int pipe_fd[2],res,pipe_fd1[2],pipe_fd2[2];
int pid,pid1,pid2;
int low=0,off=12;
//function for random delay
int random_gen(int l,int o){
		int num=(rand() %(o-l+1))+l;
	        return num;
}

// the main function of the program
int main(int argc, char* argv[])
{  
	// structure message
	struct message{time_t timestamp; char g[20]; int x;} message;
	struct message* g1; 
	struct message* g2;

	g1=(struct message*)malloc(sizeof(struct message));
	g1->x = 1;
	g1->timestamp;
	strcpy(g1->g,"G1");

	g2=(struct message*)malloc(sizeof(struct message));
	g2->x = 1;
	g2->timestamp;
	strcpy(g2->g,"G2");

	struct message* D1;
	struct message* D2;

	D1 = (struct message*)malloc(sizeof(struct message));
	D2 = (struct message*)malloc(sizeof(struct message));
    
	int RS = pipe(pipe_fd);
	int RS1 = pipe(pipe_fd1);
	int RS2 = pipe(pipe_fd2);

	if (RS == -1 || RS1 == -1 || RS2 == -1)
	{
		printf("\nThe creation of pipe is failed %s\n",strerror(errno));
		exit(EXIT_FAILURE);
	}
	printf("\nThe pipes created successfully\n");

	pid=fork();
	if(pid != 0){ 
		pid1 =fork();
		if(pid1!=0){
			pid2=fork(); 
			if(pid2!=0){
			   while(1){ //process R
				//passing read end of pipes G1,G2 and write end of M
	   			sprintf(buf1,"%d",pipe_fd[0]);
	   		    	sprintf(buf2,"%d",pipe_fd1[0]);
	   		    	sprintf(buf3,"%d",pipe_fd2[1]);
			    	execl("./reader","from the writer",buf1,buf2,buf3,NULL);
	     			}    
			}                    	 
			else
		 	{   //child1 g1
		    	
		    	
		     	    while(C1 < SIZE){
			 		//run upto 1 million cycles	
				C1++;
				
				//random delay function
				int delay=off+random_gen(low,off); 
				usleep(delay);
				
	     			write(pipe_fd[1],g1,sizeof(*g1)); 
	 			time(&g1->timestamp);
				g1->x = C1;
					  
				usleep(5);
				write(pipe_fd[1], &delay, sizeof(delay));
		     		
		     		usleep(5);
				write(pipe_fd[1], &C1, sizeof(C1));
				} 
	   		}
		}
		else
		{   //child2 g2
	       
	   	while(C2<1000000){	
			C2++;
			
			int delay1=off+random_gen(low,off);  
			usleep(delay1);
			
			write(pipe_fd1[1],g2,sizeof(*g2));
			time(&g2->timestamp);
			g2->x = C2;
			  
			usleep(5);
			write(pipe_fd1[1], &delay1, sizeof(delay1));
			
			usleep(5);
			write(pipe_fd1[1], &C2, sizeof(C2)); 	
			}
		}
	}
	else
	{   //process M child3   
		while(1){   
	  	 //passing read end pipe of process m
	   	sprintf(buf,"%d",pipe_fd2[0]);
	   	execl("./m","from the writer",buf,NULL);
		} 
	}
	   
return 0;
}

