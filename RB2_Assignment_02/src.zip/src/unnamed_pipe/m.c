/*Unnamed Pipe main PROCESS*/

// headers files
#include <stdio.h> //header file for input/output. 
#include <string.h> //header file for handle strings
#include <unistd.h> //header file for POSIX operating system API
#include <stdlib.h> //header file for general purpose standard library 
#include <sys/types.h> //header file for system source code data types
#include <sys/stat.h> //header file for symbolic values for type mode_t values
#include <fcntl.h> //header file for file control
#include <signal.h> //header file for  program signals handling during execution.
#include <time.h> //header file for time related functions
#include <math.h> //header file for mathematical operations
#include <errno.h> //header file for macros for "error number".

// the size of message
#define MSGSIZE 1000000
// declaring variables
int fd;
int del1,del2;
int C1,C2,nb;
float A1,A2;
long int L,Ls;

// the main function of the program
int main(int argc, char* argv[]) {
	
	char buf[20]; // buffer array
	memset (buf,'\0',sizeof(buf));
	sscanf(argv[1],"%d",&fd);

	// structure message
	struct message{time_t timestamp; char g[20]; int x;} message;
	struct message* D1;
	struct message* D2;
	D1 = (struct message*)malloc(sizeof(struct message));
	D2 = (struct message*)malloc(sizeof(struct message));

	// structure queue 
	struct queue{time_t timestamp; struct message buf1[MSGSIZE];} queue;
	struct queue* Q1;
	struct queue* Q2;
	Q1 = (struct queue*)malloc(sizeof(struct queue));
	Q2 = (struct queue*)malloc(sizeof(struct queue));

	usleep(2);
	read(fd,D1,sizeof(*D1));
	
	printf("\n\n---------------------------");
	printf("\nG1 data :%s ", D1->g);
	printf("\nNumber of messages recieved  : %d ", D1->x);
	printf("\n---------------------------");

	usleep(2);
	read(fd,D2,sizeof(*D2));
	printf("\n\n---------------------------");
	printf("\nG1 data :%s ", D2->g);
	printf("\nNumber of messages recieved  : %d ", D2->x);
	printf("\n---------------------------");
	
	usleep(2);
	read(fd, &del1, sizeof(del1));
	printf("\n\n---------------------------");
	printf("\nOffset delay for G1:%d", del1);
	printf("\n---------------------------");

	usleep(2);
	read(fd, &del2, sizeof(del2));
	printf("\n\n---------------------------");
	printf("\nOffset delay for G2:%d", del2);
	printf("\n---------------------------");

	usleep(2);
	read(fd, &C1, sizeof(C1));
	printf("\n\n---------------------------");
	printf("\nNo. of cycles for G1 :%d", C1);
	printf("\n---------------------------");
	
	usleep(2);
	read(fd, &C2, sizeof(C2));
	printf("\n\n---------------------------");
	printf("\nNo. of cycles for G2 :%d", C2);
	printf("\n---------------------------");
    
	usleep(2);
	read(fd, &A1, sizeof(A1));	//average g1
	usleep(2);
	read(fd, &A2, sizeof(A2));	//average g2

	usleep(2); 
	L=(A1+A2)/2; //to get average latency in microseconds
	printf("\n\n---------------------------");
	printf("\nAverage delay latency :%ld", L);
	printf("\n----------------------------");
	

	printf("\n\n---------------------------");
	printf("\nsize of G1:%lu and G2:%lu",sizeof( *D1),sizeof( *D2));
	printf("\n---------------------------");

	Ls=((A1/1000000)+(A2/1000000));
	nb=(sizeof( *D1)*8)+(sizeof( *D2)*8);
	
	printf("\n\n---------------------------");
	printf("\nEstimated Bandwidth in bits/s :%ld", nb%Ls);
	printf("\n----------------------------");
	
	return 0;
} 
