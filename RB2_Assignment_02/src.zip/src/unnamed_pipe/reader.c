/* Unnamed Pipe Reader PROCESS*/

// headers files
#include <stdio.h> //header file for input/output. 
#include <string.h> //header file for handle strings
#include <unistd.h> //header file for POSIX operating system API
#include <stdlib.h> //header file for general purpose standard library 
#include <sys/types.h> //header file for system source code data types
#include <sys/stat.h> //header file for symbolic values for type mode_t values
#include <sys/wait.h> // header file for symbolic constants 
#include <fcntl.h> //header file for file control
#include <time.h> //header file for time related functions
#include <errno.h> //header file for macros for "error number".

// the size of message
#define SIZE 1000000

//variable declartion
int Sum1=0,Sum2=0, i=0, j=0;
int fd1,fd2,fd3,C1,C2,del1,del2, retval;
char buf1[20], buf2[20], buf3[20];
long int lat_g1[SIZE],lat_g2[SIZE];
float avg, avg1;	

// the main function of the program
int main(int argc, char* argv[]) {
    
	memset (buf1,'\0',sizeof(buf1));
	memset (buf2,'\0',sizeof(buf2));
	memset (buf3,'\0',sizeof(buf3));
	sscanf(argv[1],"%d",&fd1);
	sscanf(argv[2],"%d",&fd2);
	sscanf(argv[3],"%d",&fd3);

	struct message{ time_t timestamp; char g[20]; int x;}message;
	struct message* D1;
	struct message* D2;

	D1 = (struct message*)malloc(sizeof(struct message));
	D2 = (struct message*)malloc(sizeof(struct message));

	struct queue{time_t timestamp[SIZE]; struct message buf1[SIZE];}queue;
	struct queue* Q1;
	struct queue* Q2;

	Q1 = (struct queue*)malloc(sizeof(struct queue));
	Q2 = (struct queue*)malloc(sizeof(struct queue));

	Q1->buf1[SIZE];
	Q2->buf1[SIZE];
	Q1->timestamp[SIZE];
	Q2->timestamp[SIZE];
	      
	printf("\n The start of processes ececution\n");
	
	struct timeval tv;
	tv.tv_sec = 0;
	tv.tv_usec = 5;
	fd_set rfds;
     //select to read from both g1 and g2
     do{
		
		FD_ZERO(&rfds);
		FD_SET(fd1, &rfds);
		FD_SET(fd2, &rfds);
		
		retval = select(FD_SETSIZE + 1, &rfds, NULL, NULL, &tv);
		
	    if (retval == -1){ 
	    	perror("SELECT");
		} 
		else if (retval>0) {
	        	if (FD_ISSET(fd1, &rfds))
	                {
	                //put the all read messages in ques
				if (read(fd1, D1, sizeof(*D1)) < 0)  {
                			perror("Error at data 1 ");
                			return 1;
            			}
				Q1->buf1[i].x=D1->x;
				strcpy(Q1->buf1[i].g,D1->g);
				Q1->buf1[i].timestamp=D1->timestamp;	                           
				time(&Q1->timestamp[i]);              
				//time difference between start and end 
				lat_g1[i]=difftime(Q1->timestamp[i],Q1->buf1[i].timestamp);
				//get all the time difference values
				for(int m=0;m<SIZE;m++){
				Sum1+=lat_g1[m];
				}

				avg=Sum1/SIZE;
				usleep(5);
				
				read(fd1, &del1, sizeof(del1));
				del1++;
				usleep(5);
				read(fd1, &C1, sizeof(C1));
				i++;
            		}
        		
			if (FD_ISSET(fd2, &rfds))
               	{
				if (read(fd2, D2, sizeof(*D2)) < 0)  {
					perror("Error at data 2 ");
					return 1;
				}

				Q2->buf1[j].x=D2->x;
				strcpy(Q2->buf1[j].g,D2->g); 
				Q2->buf1[j].timestamp=D2->timestamp;	
				time(&Q2->timestamp[j]);		
				lat_g2[j]=difftime(Q2->timestamp[j],Q2->buf1[j].timestamp);

				for(int n=0;n<SIZE;n++){
					Sum2+=lat_g2[n];
					}

				avg1=Sum2/SIZE;		
				usleep(5);

				read(fd2, &del2, sizeof(del2));
				del2++;
				usleep(5);
				read(fd2, &C2, sizeof(C2));
				j++;
				}
	       }
		
		//after termination write to m
		if(C1 == SIZE-1 && C2 == SIZE-1){
	 		write(fd3,D1, sizeof(*D1));
	 		usleep(2);
	 		write(fd3,D2, sizeof(*D2));
	 		usleep(2);
	 		write(fd3,&del1, sizeof(del1));
	 		usleep(2);
	 		write(fd3,&del2, sizeof(del2));
	 		usleep(2);
	 		write(fd3,&C1, sizeof(C1));
	 		usleep(2);
	 		write(fd3,&C2, sizeof(C2));
	 		usleep(2);
	 		write(fd3,&avg, sizeof(avg));
	 		usleep(2);
	 		write(fd3,&avg1, sizeof(avg1));
	 		usleep(2);
	    	}
	}while(1); 
	
    close(fd1);
    close(fd2);
    close(fd3);
    return 0;
}
