// G2 PROCESS (named pipe)

/* To compile: gcc g2.c -o g1
   To Exec: ./g2
*/

#include <stdio.h>  
#include <stdlib.h> 
#include <string.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <sys/wait.h> 
#include <time.h> 
#include <errno.h> 
#include <fcntl.h> 
#include <sys/stat.h>

#define SIZE 1000000

char * myfifo_g2 = "/tmp/g2";
int fd_g2, count_g2 = 0;
int low=0,off=15;
int cycle=0;

//function to generate random number for delay
int random_gen(int l,int o){
	int num=(rand() % (o - l + 1)) + 1;
	return num;
}

int main(int argc, char* argv[]) 
{

   if (mkfifo(myfifo_g2, 0666) != 0) {
        perror("Cannot create fifo G2. Already Exist!");
        return 1;
    	}
    //struct message g1
     struct message{
        time_t timestamp;
        int x;
        char g[10];
     }message;
     
     struct message* data_g2;
     data_g2=(struct message*)malloc(sizeof(struct message));
     data_g2->timestamp;
     data_g2->x = 1;
     strcpy((*data_g2).g,"g2");
     
     fd_g2 = open(myfifo_g2, O_WRONLY);
    	if (fd_g2 == -1) {
		perror("Cannot open fifo G2");
		unlink(myfifo_g2);
		exit(1);
		}	
  
  while(cycle < SIZE){
      count_g2++;
      
      int delay = off + random_gen(low,off); 
      usleep(delay);
      
      write(fd_g2,data_g2,sizeof(*data_g2));
      time(&data_g2->timestamp);
      data_g2->x = count_g2; 
      
      usleep(5);
      write(fd_g2, &delay, sizeof(delay));
      usleep(5);
      write(fd_g2, &count_g2, sizeof(count_g2));
      cycle++;
      printf("cycle: %d \n", cycle);
  }
    
    close(fd_g2); 
    unlink(myfifo_g2);
    
    return 0;
} 
