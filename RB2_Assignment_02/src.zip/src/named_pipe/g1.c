// G1 PROCESS (named pipe)

/* To compile: gcc g1.c -o g1
   To Exec: ./g1
*/

#include <stdio.h>  
#include <stdlib.h> 
#include <string.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <sys/wait.h> 
#include <time.h> 
#include <errno.h> 
#include <fcntl.h> 
#include <sys/stat.h>

#define SIZE 1000000

char * myfifo_g1 = "/tmp/g1";
int fd_g1, count_g1 = 0;
int low=0,off=15;
int cycle=0;

//function to generate random number for delay
int random_gen(int l,int o){
	int num=(rand() % (o - l + 1)) + 1;
	//printf("%d",num);
	return num;
}

int main(int argc, char* argv[]) {
    
    if (mkfifo(myfifo_g1, 0666) != 0) {
        perror("Cannot create fifo G1. Already Exist!");
        return 1;
    	}
    	printf("g1 fifo created successfully \n");
    //struct message for g1
     struct message{
        time_t timestamp;
        int x;
        char g[10];
     }message;
     
     struct message* data_g1;
     data_g1=(struct message*)malloc(sizeof(struct message));
     data_g1->timestamp;
     data_g1->x = 1;
     strcpy((*data_g1).g,"g1");
     
     printf("open fd\n");
     printf("fd value %d", fd_g1);
     
     fd_g1 = open(myfifo_g1, O_WRONLY);
     printf("fd value %d", fd_g1);
    	if (fd_g1 == 0) {
		perror("Cannot open fifo G1");
		unlink(myfifo_g1);
		exit(1);
		}
		
    //1 million cycles run by g1
    while(cycle < SIZE){
      count_g1++;
      
      //time delay function
      int delay = off + random_gen(low,off);
      usleep(delay);
      
      write(fd_g1,data_g1,sizeof(*data_g1));
      time(&data_g1->timestamp);    	//time stamp to get the time when writig  
      data_g1->x = count_g1; 
      
      usleep(5);
      write(fd_g1, &delay, sizeof(delay));
      usleep(5);
      write(fd_g1, &count_g1, sizeof(count_g1));
      cycle++;
      printf("cycle: %d \n", cycle);
      }

    close(fd_g1); 
    unlink(myfifo_g1);
    
    return 0;
}
