// R PROCESS (named pipe)

/* To compile: gcc r.c -o r
   To Exec: ./r
*/

#include <stdio.h> 
#include <string.h>
#include <fcntl.h> 
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h> 
#include <signal.h>
#include <errno.h>
#include <math.h>
#include <time.h> 

#define SIZE 1000000

// declared varibales
char * myfifo_g1 = "/tmp/g1";
char * myfifo_g2 = "/tmp/g2";
char * myfifo_m = "/tmp/m";

int count_g1 = 0, count_g2 = 0;
int delay, delay1, retval, i=0, j=0;
long int lat_g1[SIZE], lat_g2[SIZE], sum=0, sum1=0;
float avg_g1, avg_g2;

int main(int argc, char* argv[]) {

    //pipe for r to m to send the recieved data and compute bandwidth
   if (mkfifo(myfifo_m, 0666) != 0) {
        perror("Cannot create fifo M.");
    	}
    
    //opening pipes of G1,G2 for reading and M for writing to the M process
    int fd_g1 = open(myfifo_g1, O_RDONLY);
    if (fd_g1 == -1) {
		perror("Cannot open fifo G1");
		unlink(myfifo_g1);
		exit(1);
		}
    int fd_g2 = open(myfifo_g2, O_RDONLY);
    if (fd_g2 == -1) {
		perror("Cannot open fifo G2");
		unlink(myfifo_g2);
		exit(1);
		}
    int fd_m = open(myfifo_m, O_WRONLY);
    if (fd_m == -1) {
		perror("Cannot open fifo M");
		unlink(myfifo_m);
		exit(1);
		}
    
    struct message{
        time_t timestamp;
        int x;
        char g[10];
       }message;
       
        struct message* data_g1;
        struct message* data_g2;
     	data_g1 = (struct message*)malloc(sizeof(struct message));
     	data_g2 = (struct message*)malloc(sizeof(struct message));
     	
        //messages in queue recieved from G1 and G2
    struct queue{
       struct message buf[SIZE];
        time_t timestamp[SIZE];
       }queue;
       
       struct queue* q1;
       struct queue* q2;
       
       q1 = (struct queue*)malloc(sizeof(struct queue));
       q2 = (struct queue*)malloc(sizeof(struct queue));
       
       q1->buf[SIZE];
       q2->buf[SIZE];
       q1->timestamp[SIZE];
       q2->timestamp[SIZE];
   
    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    fd_set rfds;
    
    while(1){
        
    //select function to read the data from g1 and g2 randomly
        FD_ZERO(&rfds);
        FD_SET(fd_g1, &rfds);
        FD_SET(fd_g2, &rfds);
        retval = select(FD_SETSIZE + 1, &rfds, NULL, NULL, &tv);

        if (retval == -1){ 
            perror("SELECT");
        } 
        else if (retval) {            
        //for G1 process
        	if (FD_ISSET(fd_g1, &rfds))
        	{
            	    if (read(fd_g1, data_g1, sizeof(*data_g1)) == -1) {
                	perror("Error in reading G1");
                	return 1;
           		}
            
		    q1->buf[i].x=data_g1->x;
		    strcpy(q1->buf[i].g,data_g1->g);
		    q1->buf[i].timestamp=data_g1->timestamp;
		    time(&q1->timestamp[i]);                       
		    			
		    lat_g1[i]=difftime(q1->timestamp[i],q1->buf[i].timestamp);
		    			
		    for(int m=0;m<SIZE;m++)
		    {
		    	sum+=lat_g1[m];
		    }
		    			
		    avg_g1=sum/SIZE;
		    usleep(5);
		    read(fd_g1, &delay, sizeof(delay));
		    delay++;    
		    usleep(5);
		    read(fd_g1, &count_g1, sizeof(count_g1));
		    j++;

        	}
        	//For G2 process
        	if (FD_ISSET(fd_g2, &rfds))
        	{
            	    if(read(fd_g2, data_g2, sizeof(*data_g2)) == -1) {
                	perror("Error in reading G2 ");
                	return 1;
            	    }
            	    
        	    q2->buf[j].x=data_g2->x;
		    strcpy(q2->buf[j].g,data_g2->g); 
             	    q2->buf[j].timestamp=data_g2->timestamp;
             	    time(&q2->timestamp[j]);
            	    lat_g2[j]=difftime(q2->timestamp[j],q2->buf[j].timestamp);
                    
                    //calculate the time of recieving and sending to calculate the latency
            	    for(int n=0;n<SIZE;n++)
            	    {
            		sum1+=lat_g2[n];
            	    }
            			
              	    avg_g2=sum1/SIZE;
            	    usleep(5);
             	    read(fd_g2, &delay1, sizeof(delay1));
              	    delay1++;
             	    usleep(5);
             	    read(fd_g2, &count_g2, sizeof(count_g2));	      
        	    j++;
        	    }
    	}
	//after 1 millon cycles R sent recieved data to M
	if(count_g1 == SIZE-1 && count_g2 == SIZE-1){			
               			
 		write(fd_m,data_g1, sizeof(*data_g1));
 		usleep(2);
 		write(fd_m,data_g2, sizeof(*data_g2));
 		usleep(2);
 		write(fd_m,&delay, sizeof(delay));
 		usleep(2);
 		write(fd_m,&delay1, sizeof(delay1));
 		usleep(2);
 		write(fd_m,&count_g1, sizeof(count_g1));
 		usleep(2);
 		write(fd_m,&count_g2, sizeof(count_g2));
 		usleep(2);
 		write(fd_m,&avg_g1, sizeof(avg_g1));
 		usleep(2);
 		write(fd_m,&avg_g2, sizeof(avg_g2));
 		usleep(2);
	        }	
	}

   // closing fds 
    close(fd_g1);
    close(fd_g2);
    close(fd_m);
 
    unlink(myfifo_g1);
    unlink(myfifo_g2);
    unlink(myfifo_m); 
    
    return 0;
}
