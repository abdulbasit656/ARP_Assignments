// M PROCESS (named pipe)

/* To compile: gcc m.c -o m
   To Exec: ./m
*/

#include <stdio.h> 
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include <math.h>
#include <time.h>

// declared message size
#define SIZE 1000000

char * myfifo_m = "/tmp/m";

int delay,delay1;
int count_g1,count_g2,bits;
float avg_g1,avg_g2;
long int lat,lat_sec;
    
int main(int argc, char* argv[]) {
    
    int fd_m = open(myfifo_m, O_RDONLY);
    if (fd_m == 0) {
		perror("Cannot open fifo M");
		unlink(myfifo_m);
		exit(1);
		}
    
    // structure message
    struct message{
        time_t timestamp;
        int x;
        char g[10];
     }message;
     
     struct message* data_g1;
     struct message* data_g2;
     data_g1 = (struct message*)malloc(sizeof(struct message));
     data_g2 = (struct message*)malloc(sizeof(struct message));
    
    usleep(2);
    read(fd_m,data_g1,sizeof(*data_g1));
    printf("\n\n---------------------------");
    printf("\nG1 data :%s ", data_g1->g);
    printf("\nNumber of messages recieved  : %d ", data_g1->x);
    printf("\n---------------------------");
    
    usleep(2);
    read(fd_m,data_g2,sizeof(*data_g2));
    printf("\n\n---------------------------");
    printf("\nG2 data :%s ", data_g2->g);
    printf("\nNumber of messages recieved  : %d ", data_g2->x); 
    printf("\n---------------------------");
    
    usleep(2);
    read(fd_m, &delay, sizeof(delay));
    printf("\n\n---------------------------");
    printf("\nOffset delay for G1:%d", delay);
    printf("\n---------------------------");
    
    usleep(2);
    read(fd_m, &delay1, sizeof(delay1));
    printf("\n\n---------------------------");
    printf("\nOffset delay for G2:%d", delay1);
    printf("\n---------------------------");
    
    usleep(2);
    read(fd_m, &count_g1, sizeof(count_g1));
    printf("\n\n---------------------------");
    printf("\nNo. of cycles for G1 :%d", count_g1);
    printf("\n---------------------------");
    
    usleep(2);
    read(fd_m, &count_g2, sizeof(count_g2));
    printf("\n\n---------------------------");
    printf("\nNo. of cycles for G2 :%d", count_g2);
    printf("\n---------------------------");
    
    usleep(2);
    read(fd_m, &avg_g1, sizeof(avg_g1));
    
    usleep(2);
    read(fd_m, &avg_g2, sizeof(avg_g2));
    
    //latancy in microseconds
    lat=((avg_g1)+(avg_g2))/2;
    printf("\n\n---------------------------");
    printf("\nAverage delay latency :%ld",lat);
    printf("\n----------------------------");
    
    //latancy in secondss
    lat_sec=((avg_g1/SIZE)+(avg_g2/SIZE));
    printf("\n\n---------------------------");
    printf("\nSize of G1 :%lu \nSize of G2 :%lu",sizeof( *data_g1),sizeof( *data_g2));
    printf("\n---------------------------");
    
    bits=(sizeof( *data_g1)*8)+(sizeof( *data_g2)*8);
    printf("\n\n---------------------------");
    printf("\nEstimated Bandwidth in bits/s :%ld", bits%lat_sec);
    printf("\n----------------------------");
    
    return 0;
} 

