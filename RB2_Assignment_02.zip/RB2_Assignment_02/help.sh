#!/bin/bash

clear

more -d ./ProjectDescription.txt
more -d ./src/named_pipe/g1.txt
more -d ./src/named_pipe/g2.txt
more -d ./src/named_pipe/r.txt
more -d ./src/named_pipe/m.txt
more -d ./src/unnamed_pipe/writer.txt
more -d ./src/unnamed_pipe/reader.txt
more -d ./src/unnamed_pipe/m.txt
