
clear
more -d ./general_instructions.txt;
more -d ./simulator/master/master.txt;
more -d ./simulator/command/command.txt;
more -d ./simulator/motor_h/motor_h.txt;
more -d ./simulator/motor_v/motor_v.txt;
more -d ./simulator/inspection/inspection.txt;
more -d ./simulator/watchdog/watchdog.txt;

