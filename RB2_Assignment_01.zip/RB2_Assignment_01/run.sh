#Master process will be executed in the "executables" directory

clear
cd simulator/executables; 
./master;
