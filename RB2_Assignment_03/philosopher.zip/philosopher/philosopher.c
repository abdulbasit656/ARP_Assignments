/*

To run: gcc philosopher.c -o philosopher -lpthread -lrt 
	-lpthread & -lrt aurgument are used link threads and semaphore library with code 
	Link to POSIX real-time and threads extension library to build
*/

#include <stdio.h> 
#include <stdlib.h> 
#include <sys/mman.h> 
#include <sys/types.h> 
#include <sys/stat.h> 
#include <fcntl.h> 
#include <unistd.h>
#include <string.h>
#include <sys/shm.h> 
#include <semaphore.h> 

// paths for shared memory defined
#define SHMOBJ_PATH1 "/shm_AOS_1"
#define SHMOBJ_PATH2 "/shm_AOS_2"
#define SHMOBJ_PATH3 "/shm_AOS_3"
#define SHMOBJ_PATH4 "/shm_AOS_4"
#define SHMOBJ_PATH5 "/shm_AOS_5"
// paths for semaphores
#define SEM_PATH_1 "/sem_AOS_1"
#define SEM_PATH_2 "/sem_AOS_2"
#define SEM_PATH_3 "/sem_AOS_3"
#define SEM_PATH_4 "/sem_AOS_4"
#define SEM_PATH_5 "/sem_AOS_5"

#define SIZE 4096		//size in bits

//char *SHMOBJ_PATH[5] = {"/shm_AOS1", "/shm_AOS2", "/shm_AOS3", "/shm_AOS4", "/shm_AOS5"};

char *chopstick[5]={"FORK 1","FORK 2","FORK 3","FORK 4","FORK 5"}; 
char * ptr,*ptr1,*ptr2,*ptr3,*ptr4; 
int pid,pid1,pid2,pid3,pid4;
int delay;


//generate random period of time ranges 1-5 sec
int random_time(){ 
	int num = (rand() % 5) + 1; 
	return num; 
}

//Philosopher 1 code
int philosopher1(){
	sem_t * sem_id1 = sem_open(SEM_PATH_1, 1);
	sem_t * sem_id5 = sem_open(SEM_PATH_2, 1);
	while(1){
		
        	printf("Philosopher 1 is thinking\n"); 
        	printf("Philosopher 1 is hungry\n");
		
		sem_wait(sem_id1); 
		sem_wait(sem_id5); 
		
		printf("philosopher 1 picks: %s & %s\n", (char *)ptr,(char *)ptr1); 
		printf("Philosopher 1 is eating\n");
		
		delay = random_time();
		sleep(delay);

		sem_post(sem_id1); 
		sem_post(sem_id5);
		printf("philosopher 1 putdown: %s & %s\n", (char *)ptr,(char *)ptr1); 
 		}
 	return 1;	
}

//Philosopher 2 code
int philosopher2(){
	sem_t * sem_id1 = sem_open(SEM_PATH_1, 1);
	sem_t * sem_id2 = sem_open(SEM_PATH_2, 1);
	while(1){
       	printf("Philosopher 2 is thinking\n"); 
		printf("Philosopher 2 is hungry\n");
		
		sem_wait(sem_id1); 
		sem_wait(sem_id2); 
		
		printf("philosopher 2 picks: %s & %s\n", (char *)ptr1,(char *)ptr2); 
		printf("Philosopher 2 is eating\n");
		
		delay = random_time();
		sleep(delay);

		sem_post(sem_id1); 
		sem_post(sem_id2); 
		
		printf("philosopher 2 putdown: %s & %s\n", (char *)ptr1,(char *)ptr2); 
		}
	return 1;
}

//Philosopher 3 code
int philosopher3(){
	sem_t * sem_id2 = sem_open(SEM_PATH_2, 1);
	sem_t * sem_id3 = sem_open(SEM_PATH_3, 1);
	while(1){
		printf("Philosopher 3 is thinking\n"); 
		printf("Philosopher 3 is hungry\n");
		
		sem_wait(sem_id2); 
		sem_wait(sem_id3); 
		
		printf("philosopher 3 picks: %s & %s\n",(char *)ptr2,(char *)ptr3);
		printf("Philosopher 3 is eating\n"); 
		
		delay = random_time();
		sleep(delay);

		sem_post(sem_id2); 
		sem_post(sem_id3);
		
		printf("philosopher 3 putdown: %s & %s\n",(char *)ptr2,(char *)ptr3); 
		}

}

//Philosopher 4 code
int philosopher4(){
	sem_t * sem_id3 = sem_open(SEM_PATH_3, 1);
	sem_t * sem_id4 = sem_open(SEM_PATH_4, 1);
	while(1){
	
		printf("Philosopher 4 is thinking\n"); 
		printf("Philosopher 4 is hungry\n");
		
		sem_wait(sem_id3); 
		sem_wait(sem_id4); 
		
		printf("philosopher 4 picks: %s & %s\n",(char *)ptr3,(char *)ptr4); 
		printf("Philosopher 4 is eating\n"); //eatings status
		
		delay = random_time();
		sleep(delay);

		sem_post(sem_id3); 
		sem_post(sem_id4); 
		
		printf("philosopher 4 putdown: %s & %s\n",(char *)ptr3,(char *)ptr4);
		}
		return 1;
}

//Philosopher 5 code
int philosopher5(){
	sem_t * sem_id4 = sem_open(SEM_PATH_4, 1);
	sem_t * sem_id5 = sem_open(SEM_PATH_5, 1);
	while(1){
		printf("Philosopher 5 is thinking\n"); 
		printf("Philosopher 5 is hungry\n");
		
		sem_wait(sem_id4); 
		sem_wait(sem_id5); 
		
		printf("philosopher 5 picks: %s & %s\n",(char *)ptr4,(char *)ptr); 
		printf("Philosopher 5 is eating\n"); 
		
		delay = random_time();
		sleep(delay);

		sem_post(sem_id4); 
		sem_post(sem_id5); 
		
		printf("philosopher 5 putdown: %s & %s\n",(char *)ptr4,(char *)ptr); 
		}
	return 1;
}

int main(int argc, char *argv[]) 
{

	// shm_open() function establish a connection between a shared memory object and a file descriptor.
	
	int shm_fd1 = shm_open(SHMOBJ_PATH1, O_CREAT | O_RDWR, 0666);
	int shm_fd2 = shm_open(SHMOBJ_PATH2, O_CREAT | O_RDWR, 0666);
	int shm_fd3 = shm_open(SHMOBJ_PATH3, O_CREAT | O_RDWR, 0666);
	int shm_fd4 = shm_open(SHMOBJ_PATH4, O_CREAT | O_RDWR, 0666);
	int shm_fd5 = shm_open(SHMOBJ_PATH5, O_CREAT | O_RDWR, 0666);

	// ftruncate() function truncates the file indicated by the open file descriptor fildes to the indicated length.

	ftruncate(shm_fd1, SIZE);
	ftruncate(shm_fd2, SIZE);
	ftruncate(shm_fd3, SIZE);
	ftruncate(shm_fd4, SIZE);
	ftruncate(shm_fd5, SIZE);

	//creating memory mapping to the pointers
	ptr  = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED,shm_fd1, 0);
	ptr1 = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED,shm_fd2, 0);
	ptr2 = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED,shm_fd3, 0);
	ptr3 = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED,shm_fd4, 0);
	ptr4 = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED,shm_fd5, 0);
	
	//pointer correspond to each chopstick
	sprintf(ptr , "%s", chopstick[0]);
	sprintf(ptr1, "%s", chopstick[1]);
	sprintf(ptr2, "%s", chopstick[2]);
	sprintf(ptr3, "%s", chopstick[3]);
	sprintf(ptr4, "%s", chopstick[4]);
	
	// 5 named semaphores are created for read and write operations

	sem_t * sem_id1 = sem_open(SEM_PATH_1, O_CREAT, 0600, 1);
	sem_t * sem_id2 = sem_open(SEM_PATH_2, O_CREAT, 0600, 1);
	sem_t * sem_id3 = sem_open(SEM_PATH_3, O_CREAT, 0600, 1);
	sem_t * sem_id4 = sem_open(SEM_PATH_4, O_CREAT, 0600, 1);
	sem_t * sem_id5 = sem_open(SEM_PATH_5, O_CREAT, 0600, 1);

	// sem_init() function is used to initialise the unnamed semaphore

	sem_init(sem_id1, 1, 1); 
	sem_init(sem_id2, 1, 1); 
	sem_init(sem_id3, 1, 1); 
	sem_init(sem_id4, 1, 1); 
	sem_init(sem_id5, 1, 1); 

	
	//forking 5 process one per philosopher
	
	pid=fork();
	if(pid != 0){ 
     	pid1=fork();
     	
     	if(pid1!=0){
     		pid2=fork();
     			
     		if(pid2 != 0){
			pid3=fork();
			
     			if(pid3 != 0){
     				pid4=fork();
     				
     				if(pid4 != 0){
     						
					philosopher4();
				
	 				}
			 	else{  
				 	philosopher5();
				    }
        		}
			else{  
				philosopher3();
			    
			    }
        	}
        	else{
			philosopher2();
       	    }
       } 
       else{
		philosopher1();
 	   }
       }

//clean all semaphores and shared memory and exit
/*shm_unlink(SHMOBJ_PATH1);
shm_unlink(SHMOBJ_PATH2);
shm_unlink(SHMOBJ_PATH3);
shm_unlink(SHMOBJ_PATH4);
shm_unlink(SHMOBJ_PATH5);

sem_close(sem_id1);
sem_close(sem_id2);
sem_close(sem_id3);
sem_close(sem_id4);
sem_close(sem_id5);
sem_unlink(SEM_PATH_1);
sem_unlink(SEM_PATH_2);
sem_unlink(SEM_PATH_3);
sem_unlink(SEM_PATH_4);
sem_unlink(SEM_PATH_5);
munmap(ptr, SIZE);
munmap(ptr1, SIZE);
munmap(ptr2, SIZE);
munmap(ptr3, SIZE);
munmap(ptr4, SIZE);
*/
return 0;
} 

